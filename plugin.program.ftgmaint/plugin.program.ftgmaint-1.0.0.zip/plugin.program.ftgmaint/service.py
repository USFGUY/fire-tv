import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,base64,sys,xbmcvfs
import urllib2,urllib
import re
import time
import common as Common
import plugintools
from random import randint
from datetime import date
import calendar
import acdays
import maintenance

my_date = date.today()
today = calendar.day_name[my_date.weekday()]
addon_id   = 'plugin.program.ftgmaint'
AddonTitle = "[COLOR red]FTG Maintenance[/COLOR]"

acdays.Checker()
maintenance.Auto_Startup()
