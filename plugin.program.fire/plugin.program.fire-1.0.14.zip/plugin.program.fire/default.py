#%F%T%G%##%F%T%G%##%F%T%G%##%F%T%G%##%F%T%G%##%F%T%G%##%F%T%G%##%F%T%G%##%F%T%G%##%F%T%G%##%F%T%G%#
#############                                                                      ################
############# If your going to use my Wizard at least give credit to those involed ################
#############                                                                      ################
#%F%T%G%##%F%T%G%##%F%T%G%##%F%T%G%##%F%T%G%##%F%T%G%##%F%T%G%##%F%T%G%##%F%T%G%##%F%T%G%##%F%T%G%#



import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,sys,random
from addon.common.addon import Addon
from addon.common.net import Net
import shutil
import urllib2,urllib
import re, glob
import time
import plugintools
import downloader
import zipfile
import extract
import GoDev
import zipfile
import ntpath
import maintenance
global debuglog
global killkodi
global plugintools
net = Net()

USER_AGENT = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
ADDON=xbmcaddon.Addon(id='plugin.program.fire')
AddonID = 'plugin.program.fire'
addon_id = 'plugin.program.fire'
MainPath=xbmc.translatePath(os.path.join('special://home','addons',AddonID));#!F!T!G!#
Images=xbmc.translatePath(os.path.join('special://home','addons',AddonID,'resources','art/')); 
fanarts         = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.png'))
icon            = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png')) 
FanArt = xbmc.translatePath(os.path.join(MainPath,'FanArt.png'));
HOME =  xbmc.translatePath('special://home/')
ADDONS =  xbmc.translatePath(os.path.join('special://home','addons',''))
Dialog =  xbmcgui.Dialog()
dialog =  xbmcgui.Dialog()
DialogProcess =  xbmcgui.DialogProgress()
USERDATA =  xbmc.translatePath(os.path.join('special://home/userdata',''))
GUISETTINGS =  os.path.join(USERDATA,'guisettings.xml')
THUMBNAILS =  xbmc.translatePath(os.path.join(USERDATA,'Thumbnails'))
zip =  ADDON.getSetting('zip')
USB =  xbmc.translatePath(os.path.join(zip))
skin =  xbmc.getSkinDir()
VERSION = ""#!F!T!G!#
PATH = "Fire TV Guru Wizard"
backupdir    =  xbmc.translatePath(os.path.join('special://home/backupdir',''))
dp =  xbmcgui.DialogProgress()

def OPEN_SETTINGS(params):
    plugintools.open_settings_dialog()

#^F^T^G^##^F^T^G^##^F^T^G^##^F^T^G^##^F^T^G^##^F^T^G^##^F^T^G^##^F^T^G^##^F^T^G^##^F^T^G^##^F^T^G^##^F^T^G^#
#############                                                                                  #############
############# If yo|ur goi|ng to us|e my Wiza|rd at lea|st gi|ve cre|dit to th|ose invo|led    #############
#############                                                                                  #############
#^F^T^G^##^F^T^G^##^F^T^G^##^F^T^G^##^F^T^G^##^F^T^G^##^F^T^G^##^F^T^G^##^F^T^G^##^F^T^G^##^F^T^G^##^F^T^G^#

def MainMenu():
	HOME       =  xbmc.translatePath('special://home/')
	CACHE      =  xbmc.translatePath(os.path.join('special://home/cache',''))
	PACKAGES   =  xbmc.translatePath(os.path.join('special://home/addons','packages'))
	THUMBS     =  xbmc.translatePath(os.path.join('special://home/userdata','Thumbnails'))

	if not os.path.exists(CACHE):
		CACHE     =  xbmc.translatePath(os.path.join('special://home/temp',''))
	if not os.path.exists(PACKAGES):
		os.makedirs(PACKAGES)

	try:
		CACHE_SIZE_BYTE    = get_size(CACHE)#!F!T!G!#
		PACKAGES_SIZE_BYTE = get_size(PACKAGES)
		THUMB_SIZE_BYTE    = get_size(THUMBS)
	except: pass
	
	try:
		CACHE_SIZE    = convertSize(CACHE_SIZE_BYTE)
		PACKAGES_SIZE = convertSize(PACKAGES_SIZE_BYTE)
		THUMB_SIZE    = convertSize(THUMB_SIZE_BYTE)
	except: pass
	addFolder('folder','[COLOR orangered][B]Fire TV Guru Builds[/COLOR][/B]','fanart', 'FireTVBuildMenu', 'icon.png',fanarts,'','')
	addFolder('folder','[COLOR blue][B]Extra Addons and Fixes[/COLOR][/B]','fanart', 'FixesMenu', 'icon.png',fanarts,'','')
	addFolder('folder','[COLOR lime][B]App Installer[/COLOR][/B]','fanart', 'AppInstaller', 'icon.png',fanarts,'','')	
	addFolder('folder','[COLOR cyan][B]Maintenance and Tools[/COLOR][/B]','fanart', 'MAINTENANCE_MENU', 'icon.png',fanarts,'','')
	addFolder('',"[COLOR blue][B]-------------------------------------------------[/B][/COLOR]",'url',79,'icon.png',fanarts,'')
	addFolder('',"[COLOR lime][B]Cache Size = [/B][/COLOR]" + str(CACHE_SIZE),'url',6,'icon.png',fanarts,'')
	addFolder('',"[COLOR lime][B]Packages Size = [/B][/COLOR]" + str(PACKAGES_SIZE),'url',8,'icon.png',fanarts,'')
	addFolder('',"[COLOR lime][B]Thumbnails Size = [/B][/COLOR]" + str(THUMB_SIZE),'url',7,'icon.png',fanarts,'')
	addFolder('',"[COLOR blue][B]-------------------------------------------------[/B][/COLOR]",'url',79,'icon.png',fanarts,'')#!F!T!G!#
	addFolder('',"[COLOR yellow][B]Show External IP Address[/B][/COLOR]",'url',13,'icon.png',fanarts,'')
	addFolder('folder','[COLOR tan][B]Backup Options[/COLOR][/B]','fanart', 'BackupMenu', 'icon.png',fanarts,'','')#!F!T!G!#
	addFolder('folder','[COLOR red][B]!!!-->Fresh Start<--!!![/COLOR][/B]','fanart', 'FreshStart', 'icon.png',fanarts,'','')
	setView('movies', 'MAIN')
	

	
#!F!T!G!##!F!T!G!##!F!T!G!##!F!T!G!##!F!T!G!##!F!T!G!##!F!T!G!##!F!T!G!##!F!T!G!##!F!T!G!##!F!T!G!##!F!T!G!##!F!T!G!##!F!T!G!##!F!T!G!##!F!T!G!##!F!T!G!##!F!T!G!##!F!T!G!#
def FireTVBuildMenu():
	link = OPEN_URL('http://firetvguru.net/build/buildcat.xml').replace('\n','').replace('\r','')
	match=re.compile('<title>(.+?)</title>.+?url>(.+?)</url>.+?thumb>(.+?)</thumb>.+?fanart>(.+?)</fanart>',re.DOTALL).findall(link)
	for name,url,iconimage,fanart in match:
		name = name.replace(' - ',' ')
		iconimage = iconimage.replace(' ','%20') 
		url = url.replace(' ','%20')##F#T#G##
		fanart = fanart.replace(' ','%20')
		addDir(name,url,4,iconimage,fanart)
def FixesMenu():
	link = OPEN_URL('http://firetvguru.net/build/fixes.xml').replace('\n','').replace('\r','')
	match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
	for name,url,iconimage,FanArt,description in match:
		addXMLMenu(name,url,1,iconimage,FanArt,description)#!F!T!G!#
	setView('movies', 'MAIN')
def AppCat():
	link=OPEN_URL('http://firetvguru.net/build/appcatagory.xml')
	match=re.compile('<title>(.+?)</title>.+?url>(.+?)</url>.+?thumb>(.+?)</thumb>.+?fanart>(.+?)</fanart>',re.DOTALL).findall(link)
	for name,url,iconimage,fanart in match:
		name = name.replace(' - ',' ')
		iconimage = iconimage.replace(' ','%20') 
		url = url.replace(' ','%20')##F#T#G##
		fanart = fanart.replace(' ','%20')
		addDir(name,url,2,iconimage,fanart)

#!F!T!G!##!F!T!G!##!F!T!G!##!F!T!G!##!F!T!G!##!F!T!G!##!F!T!G!##!F!T!G!##!F!T!G!##!F!T!G!##!F!T!G!##!F!T!G!##!F!T!G!##!F!T!G!##!F!T!G!##!F!T!G!#


#############                                                                         #############
########## If yo#ur goi#ng to us#e my Wiz#ard at le#ast gi#ve cre#dit to th#ose inv#oled    #######
#############                                                                         #############
#(F)T(G)##(F)T(G)##(F)T(G)##(F)T(G)##(F)T(G)##(F)T(G)##(F)T(G)##(F)T(G)##(F)T(G)##(F)T(G)##(F)T(G)#
def MAINTENANCE_MENU():
	addFolder('', "[COLOR snow]Wizard Settings[/COLOR]",'none',5,'icon.png',fanarts,'')
	addFolder('','[COLOR white]View Current or Old Log File[/COLOR]','url',12,'icon.png',fanarts,'')##F#T#G##
	addFolder('',"[COLOR blue][B]-------------------------------------------------[/B][/COLOR]",'url',79,'icon.png',fanarts,'')
	addFolder('','[COLOR white]Do All Maintenance[/COLOR]','url',11,'icon.png',fanarts,'')
	addFolder('','[COLOR white]Clear Cache[/COLOR]','url',6,'icon.png',fanarts,'')
	addFolder('','[COLOR white]Delete Crash Logs[/COLOR]','url',9,'icon.png',fanarts,'')
	addFolder('','[COLOR white]Delete Thumbnails[/COLOR]','url',7,'icon.png',fanarts,'')
	addFolder('','[COLOR white]Purge Packages[/COLOR]','url',8,'icon.png',fanarts,'')
	addFolder('',"[COLOR blue][B]-------------------------------------------------[/B][/COLOR]",'url',79,'icon.png',fanarts,'')
	addFolder('','[COLOR white]Fix Addon Update Errors (Remove Addon Database)[/COLOR]','url',10,'icon.png',fanarts,'')
	addFolder('','[COLOR white]Force Update Addons/Repos[/COLOR]', 'none', 'forceUpdate', 'icon.png',fanarts,'','')
	addFolder('','[COLOR white]Force Close Media Center[/COLOR]','fanart', 'killkodi', 'icon.png',fanarts,'','')
	addFolder('folder','[COLOR red]!!!!Fresh Start!!!![/COLOR]', 'none', 'FreshStart', 'icon.png',fanarts,'','')

def FreshStart():
	addFolder('','[COLOR red][B]Fresh Start[/COLOR][/B]', 'none', 'freshstart', 'icon.png',fanarts,'','')
	addFolder('','[COLOR yellow][B]Force Close Media Center[/COLOR][/B]','fanart', 'killkodi', 'icon.png',fanarts,'','')
	addFolder('','[COLOR lime][B]Complete Wipe!![COLOR red][B] Dont use unless told to!![/COLOR][/B]', 'none', 'Wipe_Kodi', 'icon.png',fanarts,'','')
	setView('movies', 'MAIN')

	
def BackupMenu():
##needs work and modules added ####
	addFolder('','[COLOR gold][B] Backup Favorites[/B][/COLOR]','url','BackupFAV','icon.png',fanarts,'')
	addFolder('','[COLOR gold][B] Restore Favorites[/B][/COLOR]','url','RestoreFAV','icon.png',fanarts,'')
	


#######################################################################################################

def get_size(start_path):
    total_size = 0
    for dirpath, dirnames, filenames in os.walk(start_path):
        for f in filenames:
            fp = os.path.join(dirpath, f)
            total_size += os.path.getsize(fp)
    return total_size

def convertSize(size):
   import math
   if (size == 0):
       return '[COLOR yellow][B]0 MB[/COLOR][/B]'
   size_name = ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")#!F!T!G!#
   i = int(math.floor(math.log(size,1024)))
   p = math.pow(1024,i)
   s = round(size/p,2)
   if size_name[i] == "B":
        return '[COLOR lime][B]%s %s' % (s,size_name[i]) + '[/COLOR][/B]'
   if size_name[i] == "KB":##F#T#G##
        return '[COLOR yellow][B]%s %s' % (s,size_name[i]) + '[/COLOR][/B]'
   if size_name[i] == "GB":
        return '[COLOR lightskyblue][B]%s %s' % (s,size_name[i]) + '[/COLOR][/B]'
   if size_name[i] == "TB":
        return '[COLOR lightskyblue][B]%s %s' % (s,size_name[i]) + '[/COLOR][/B]'
   if s < 50:
        return '[COLOR yellow][B]%s %s' % (s,size_name[i]) + '[/COLOR][/B]'
   if s >= 50:
        if s < 100:
            return '[COLOR red][B]%s %s' % (s,size_name[i]) + '[/COLOR][/B]'
   if s >= 100:
        return '[COLOR lightskyblue][B]%s %s' % (s,size_name[i]) + '[/COLOR][/B]'

def convertSizeInstall(size):
   import math
   if (size == 0):
       return '[COLOR blue][B]0 MB[/COLOR][/B]'
   size_name = ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
   i = int(math.floor(math.log(size,1024)))
   p = math.pow(1024,i)
   s = round(size/p,2)
   if size_name[i] == "B":
        return '[COLOR lime][B]%s %s' % (s,size_name[i]) + '[/COLOR][/B]'
   if size_name[i] == "KB":
        return '[COLOR yellow][B]%s %s' % (s,size_name[i]) + '[/COLOR][/B]'
   if size_name[i] == "TB":
        return '[COLOR lightskyblue][B]%s %s' % (s,size_name[i]) + '[/COLOR][/B]'#!F!T!G!#
   if s < 1000:
        return '[COLOR yellow][B]%s %s' % (s,size_name[i]) + '[/COLOR][/B]'
   if s >= 1000:
        if s < 1500:
            return '[COLOR red][B]%s %s' % (s,size_name[i]) + '[/COLOR][/B]'
   if s >= 1500:
        return '[COLOR lightskyblue][B]%s %s' % (s,size_name[i]) + '[/COLOR][/B]'


	
################################################################################################
#############                                                                      #############
########## If yo!ur go!ing to us!e my Wiz!ard at lea!st gi!ve cr!edit to tho!se invo!led #######
#############                                                                      #############
################################################################################################



def IP_Check(url='http://myipinfo.net/',inc=1):
    match=re.compile("<h2>(.+?)</h2>").findall(net.http_GET(url).content)
    for ip in match:
        if inc <2: dialog=xbmcgui.Dialog(); dialog.ok('[COLOR blue][B]What is My IP[/B][/COLOR]',"[COLOR blue][B][/B][/COLOR]","[B][COLOR yellow]Your External IP Address is: [/COLOR][/B][B][COLOR lime]%s [/COLOR][/B] "  % ip, "[COLOR blue][B][/B][/COLOR]")
        inc=inc+1

def wizard(name,url,description):
	path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
	dp = xbmcgui.DialogProgress()
	dp.create("[COLOR dodgerblue][B]Fire Wizard[/COLOR][/B]","Downloading ",'', 'Please be Patient')
	lib=os.path.join(path,'build.zip')
	try:#!F!T!G!#
	   os.remove(lib)
	except:
	   pass
	downloader.download(url, lib, dp)
	addonfolder = xbmc.translatePath(os.path.join('special://','home'))
	time.sleep(2)
	dp.update(0,"", "[COLOR lime][B]Installing Please be Patient[/COLOR][/B]")
	print '======================================='
	print addonfolder##F#T#G##
	print '======================================='
	extract.allWithProgress(lib,addonfolder,dp)
#(F)T(G)##(F)T(G)##(F)T(G)##(F)T(G)##(F)T(G)##(F)T(G)##(F)T(G)##(F)T(G)##(F)T(G)##(F)T(G)##(F)T(G)#
	RESTOREFAVwiz()
#(F)T(G)##(F)T(G)##(F)T(G)##(F)T(G)##(F)T(G)##(F)T(G)##(F)T(G)##(F)T(G)##(F)T(G)##(F)T(G)##(F)T(G)#
	choice = xbmcgui.Dialog().yesno("[COLOR dodgerblue][B]Fire Wizard[/COLOR][/B]", 'Just installed the BUILD choose Force Close', 'Just did a fix choose Reset', '', yeslabel='FORCE CLOSE',nolabel='RESET')
	if choice == 0:
		GoDev.Wipe_Cache()
		GoDev.Delete_Packages()
		FASTRESET() 
		return
	elif choice == 1:
		GoDev.Wipe_Cache()
		GoDev.Delete_Packages()
		GoDev.killkodi()
		
def RESTOREFAVwiz():
	if os.path.exists(os.path.join(backupdir,'backup_fav.zip')):
		choice = xbmcgui.Dialog().yesno("[COLOR=red]FAVS BACKUP/RESTORE[/COLOR]", 'Do you want to Restore your favorites?', '', '', yeslabel='[COLOR=red]Yes[/COLOR]',nolabel='[COLOR=green]No[/COLOR]')
	if choice == 0:
		return
	elif choice == 1:
		import time
		dialog = xbmcgui.Dialog()
		dp =  xbmcgui.DialogProgress()
		lib=xbmc.translatePath(os.path.join(backupdir,'backup_fav.zip'))
		addonfolder = xbmc.translatePath(os.path.join('special://','home/userdata'))
		time.sleep(2)
		dp.create("[COLOR=blue][B] FTG Restore[/B][/COLOR]","Restoring",'', 'Please Wait')

		extract.all(lib,addonfolder,dp)
		dp.close()

def RESTOREFAV():
 	choice = xbmcgui.Dialog().yesno("[COLOR=red]FAVS BACKUP/RESTORE[/COLOR]", 'Do you want to Restore your favorites?', '', '', yeslabel='[COLOR=red]Yes[/COLOR]',nolabel='[COLOR=green]No[/COLOR]')
	if choice == 0:
		return
	elif choice == 1:
		import time
		dialog = xbmcgui.Dialog()
		dp =  xbmcgui.DialogProgress()
		lib=xbmc.translatePath(os.path.join(backupdir,'backup_fav.zip'))
		addonfolder = xbmc.translatePath(os.path.join('special://','home/userdata'))
		time.sleep(2)
		dp.create("[COLOR=blue][B] FTG Restore[/B][/COLOR]","Restoring",'', 'Please Wait')

		extract.all(lib,addonfolder,dp)
		dp.close()
		dialog.ok("[COLOR=red]COMPLETE[/COLOR]", '', 'Your favorites are Restored.', '')
			
def BACKUPFAV():
	choice = xbmcgui.Dialog().yesno("[COLOR=red]FFAVS BACKUP/RESTORE[/COLOR]", 'Do you want to Back-up your favorites?', '', '', yeslabel='[COLOR=red]Yes[/COLOR]',nolabel='[COLOR=green]No[/COLOR]')
	if choice == 0:
		return
	elif choice == 1:
		to_backup = xbmc.translatePath(os.path.join('special://','home/userdata'))	
		rootlen = len(to_backup)
		backup_ui_zip = xbmc.translatePath(os.path.join(backupdir,'backup_fav.zip'))
		zipobj = zipfile.ZipFile(backup_ui_zip , 'w', zipfile.ZIP_DEFLATED)
		fn = os.path.join(USERDATA, 'favourites.xml')
		dp.create("FTG BACKUP","Backing Up Favourites",'', 'Please Wait')
		zipobj.write(fn, fn[rootlen:])
		zipobj.close()
		dp.close()
		dialog.ok("[COLOR=red]COMPLETE[/COLOR]", '', 'Your favorites are Backed up.', '')

#######################################################################################################
##F#T#G##
def forceUpdate():
	xbmc.executebuiltin('UpdateAddonRepos()')
	xbmc.executebuiltin('UpdateLocalAddons()')
	Dialog.ok("[COLOR dodgerblue][B]Fire Wizard[/COLOR][/B]", '	Addons/Repos updates will be checked ', '', '')

#######################################################################################################

def FASTRESET():
	Dialog.ok("[COLOR blue]INSTALL COMPLETE[/COLOR]", 'The skin will now be reset', 'If images are not showing, just restart Kodi', 'Click OK to Continue')
	xbmc.executebuiltin('UpdateAddonRepos()')
	xbmc.executebuiltin('UpdateLocalAddons()')
	xbmc.executebuiltin('ActivateWindow(Home)')
	xbmc.executebuiltin('Mastermode')		
	xbmc.executebuiltin('LoadProfile(Master user)')
	xbmc.executebuiltin('ActivateWindow(Home)')	

#######################################################################################################

def APPINSTALL(name,url,description):
   confirm=xbmcgui.Dialog()
   if confirm.yesno(name,description,"","","Go Back","Download"):
    downloadpath = xbmc.translatePath(os.path.join('special://home/addons','packages'))
    dp = xbmcgui.DialogProgress()
    dp.create("[COLOR dodgerblue][B]FTG App Installer[/COLOR][/B]",">>>Downloading<<<",name,'>>>Please Wait<<<')##F#T#G##
    lib=os.path.join(downloadpath, name+'.apk')
    downloader.download(url, lib, dp)
    addonfolder = xbmc.translatePath(os.path.join('special://','home'))
    dialog = xbmcgui.Dialog()
    dialog.ok("[COLOR dodgerblue][B]FTG App Installer[/COLOR][/B]",">>>Download Finished<<<","",">>>Click Ok To Install<<<" + name + "")
    xbmc.executebuiltin('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+lib+'")')#    xbmc.executebuiltin("StartAndroidActivity(com.estrongs.android.pop)")
    time.sleep(4)
    dialog.ok("[COLOR dodgerblue][B]FTG App Installer[/COLOR][/B]"," "," ","THANKS FOR USING [COLOR dodgerblue]FTG App Installer[/COLOR] THX to  ][NT3L][G3NC][ for the code!!")
    try: os.remove(lib)
    except: pass


#######################################################################################################

def OPEN_URL(url):#!F!T!G!#
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
	response = urllib2.urlopen(req)##F#T#G##
	link=response.read()
	response.close()
	return link
def GetList1(url):
	link = OPEN_URL(url).replace('\n','').replace('\r','')
	match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
	for name,url,iconimage,FanArt,description in match:
		addXMLMenu(name,url,1,iconimage,FanArt,description)
	setView('movies', 'MAIN')
def GetList(url):
	link = OPEN_URL(url).replace('\n','').replace('\r','')#!F!T!G!#
	match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
	for name,url,iconimage,FanArt,description in match:
		addXMLMenu(name,url,3,iconimage,FanArt,description)
	setView('movies', 'MAIN')
		#!F!T!G!#
def addItem(name,url,mode,iconimage,fanart,description):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&fanart="+urllib.quote_plus(fanart)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={ "Title": name } )
	liz.setProperty( "Fanart_Image", fanart )
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
def addXMLMenu(name,url,mode,iconimage,FanArt,description):
		u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&FanArt="+urllib.quote_plus(FanArt)+"&description="+urllib.quote_plus(description)
		ok=True
		liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
		liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
		liz.setProperty( "FanArt_Image", FanArt )
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
		return ok
def addDir(name,url,mode,iconimage,fanart,description=''):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={ "Title": name, 'plot': description } )
	liz.setProperty('fanart_image', fanart)
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
	return ok
def addFolder(type,name,url,mode,iconimage = '',FanArt = '',video = '',description = ''):
	if type != 'folder2' and type != 'addon':
		if len(iconimage) > 0:
			iconimage = Images + iconimage
		else:##F#T#G##
			iconimage = 'DefaultFolder.png'
	if type == 'addon':
		if len(iconimage) > 0:
			iconimage = iconimage
		else:
			iconimage = 'none'
	if FanArt == '':
		FanArt = FanArt
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&FanArt="+urllib.quote_plus(FanArt)+"&video="+urllib.quote_plus(video)+"&description="+urllib.quote_plus(description)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
	liz.setProperty( "FanArt_Image", FanArt )
	liz.setProperty( "Build.Video", video )
	if (type=='folder') or (type=='folder2') or (type=='tutorial_folder') or (type=='news_folder'):
		ok=Add_Directory_Item(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
	else:
		ok=Add_Directory_Item(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
	return ok
def Add_Directory_Item(handle, url, listitem, isFolder):
	xbmcplugin.addDirectoryItem(handle, url, listitem, isFolder) 

#########################################################################################################F#T#G##

################################################################################################
#############                                                                      #############
############# If your going to use my Wizard at least give credit to those involed #############
#############                                                                      #############
################################################################################################

def get_params():
		param=[]
		paramstring=sys.argv[2]
		if len(paramstring)>=2:
				params=sys.argv[2]
				cleanedparams=params.replace('?','')
				if (params[len(params)-1]=='/'):
						params=params[0:len(params)-2]
				pairsofparams=cleanedparams.split('&')
				param={}
				for i in range(len(pairsofparams)):
						splitparams={}
						splitparams=pairsofparams[i].split('=')
						if (len(splitparams))==2:
								param[splitparams[0]]=splitparams[1]

		return param




#######################################################################################################

def platform():
	if xbmc.getCondVisibility('system.platform.android'):
		return 'android'
	elif xbmc.getCondVisibility('system.platform.linux'):
		return 'linux'
	elif xbmc.getCondVisibility('system.platform.windows'):
		return 'windows'
	elif xbmc.getCondVisibility('system.platform.osx'):##F#T#G##
		return 'osx'
	elif xbmc.getCondVisibility('system.platform.atv2'):
		return 'atv2'
	elif xbmc.getCondVisibility('system.platform.ios'):
		return 'ios'
try:
	debuglog = xbmcplugin.getSetting(int(sys.argv[1]), 'debuglog')
except:
	debuglog = "0"	
	
def setView(content, viewType):
	# set content type so library shows more views and info
	if content:
		xbmcplugin.setContent(int(sys.argv[1]), content)
	if ADDON.getSetting('auto-view')=='true':
		xbmc.executebuiltin("Container.SetViewMode(%s)" % ADDON.getSetting(viewType) )


#######################################################################################################
	
params=get_params()
url=None
name=None
mode=None
iconimage=None
FanArt=None
description=None##F#T#G##
addon_id=None
audioaddons=None
author=None
buildname=None
data_path=None
description=None
DOB=None
email=None
fanart=None
forum=None
iconimage=None
link=None
local=None
messages=None
mode=None
name=None
posts=None
programaddons=None
provider_name=None
repo_id=None
repo_link=None
skins=None
sources=None
updated=None##F#T#G##
unread=None
version=None
video=None
videoaddons=None
welcometext=None
zip_link=None
try:	addon_id=urllib.unquote_plus(params["addon_id"])
except: pass
try:	audioaddons=urllib.unquote_plus(params["audioaddons"])
except: pass
try:	author=urllib.unquote_plus(params["author"])
except: pass
try:	buildname=urllib.unquote_plus(params["buildname"])
except: pass
try:	data_path=urllib.unquote_plus(params["data_path"])
except: pass
try:	description=urllib.unquote_plus(params["description"])
except: pass
try:	DOB=urllib.unquote_plus(params["DOB"])
except: pass
try:	email=urllib.unquote_plus(params["email"])
except: pass
try:	fanart=urllib.unquote_plus(params["fanart"])
except: pass
try:	forum=urllib.unquote_plus(params["forum"])
except: pass
try:	guisettingslink=urllib.unquote_plus(params["guisettingslink"])
except: pass
try:	iconimage=urllib.unquote_plus(params["iconimage"])
except: pass##F#T#G##
try:	link=urllib.unquote_plus(params["link"])
except: pass
try:	local=urllib.unquote_plus(params["local"])
except: pass
try:	messages=urllib.unquote_plus(params["messages"])
except: pass
try:	mode=str(params["mode"])
except: pass
try:	name=urllib.unquote_plus(params["name"])
except: pass
try:	pictureaddons=urllib.unquote_plus(params["pictureaddons"])
except: pass
try:	posts=urllib.unquote_plus(params["posts"])
except: pass
try:	programaddons=urllib.unquote_plus(params["programaddons"])
except: pass
try:	provider_name=urllib.unquote_plus(params["provider_name"])
except: pass
try:	repo_link=urllib.unquote_plus(params["repo_link"])
except: pass
try:	repo_id=urllib.unquote_plus(params["repo_id"])
except: pass
try:	skins=urllib.unquote_plus(params["skins"])
except: pass
try:	sources=urllib.unquote_plus(params["sources"])
except: pass
try:	updated=urllib.unquote_plus(params["updated"])##F#T#G##
except: pass
try:	unread=urllib.unquote_plus(params["unread"])
except: pass
try:	url=urllib.unquote_plus(params["url"])
except: pass
try:	version=urllib.unquote_plus(params["version"])
except: pass
try:	video=urllib.unquote_plus(params["video"])
except: pass
try:	videoaddons=urllib.unquote_plus(params["videoaddons"])
except: pass
try:	zip_link=urllib.unquote_plus(params["zip_link"])
except: pass
try:	url=urllib.unquote_plus(params["url"])
except: pass
try:	name=urllib.unquote_plus(params["name"])
except: pass
try:	iconimage=urllib.unquote_plus(params["iconimage"])
except: pass
try:	mode=int(params["mode"])
except: pass
try:	FanArt=urllib.unquote_plus(params["FanArt"])
except: pass
try:	description=urllib.unquote_plus(params["description"])
except: pass
print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)##F#T#G##
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)

#(F)T(G)##(F)T(G)##(F)T(G)##(F)T(G)##(F)T(G)##(F)T(G)##(F)T(G)##(F)T(G)##(F)T(G)##(F)T(G)##(F)T(G)#

if mode==None or url==None or len(url)<1:
		MainMenu()
elif mode == 'FireTVBuildMenu' : FireTVBuildMenu() #FireBuildMenu
elif mode == 'FixesMenu' : FixesMenu() #FixesMenu
elif mode == 'AppInstaller' : AppCat() #AppInstaller
elif mode == 'FreshStart' : FreshStart() #FreshStart
elif mode == 'forceUpdate' : forceUpdate() #ForceUpdate
elif mode == 'BackupMenu' : BackupMenu() #BackupMenu
elif mode == 'BackupFAV': BACKUPFAV() #BackupMenu
elif mode == 'RestoreFAV': RESTOREFAV()#RestoreMenu
elif mode == 'Wipe_Kodi' : GoDev.Wipe_Kodi() #Wipe_Kodi
elif mode == 'freshstart' : GoDev.FreshStart() #Wipe_Kodi
elif mode == 'killkodi' : GoDev.killkodi() #force close
elif mode == 'MAINTENANCE_MENU':MAINTENANCE_MENU()
elif mode == 1 : wizard(name,url,description) #OpenWizard
elif mode == 2 : GetList(url)
elif mode == 3 : APPINSTALL(name,url,description) #AppInstaller
elif mode == 4 : GetList1(url)
elif mode == 5 : OPEN_SETTINGS(params)
elif mode == 6 : maintenance.clearCache()
elif mode == 7 : maintenance.deleteThumbnails()
elif mode == 8 : maintenance.purgePackages()
elif mode == 9 : maintenance.DeleteCrashLogs()
elif mode == 10: maintenance.deleteAddonDB()
elif mode == 11: maintenance.autocleanask()
elif mode == 12: maintenance.viewLogFile()
elif mode == 13: IP_Check()
##F#T#G##
######################################################################################

xbmcplugin.endOfDirectory(int(sys.argv[1]))