import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,base64,sys,xbmcvfs
import shutil
import urllib2,urllib
import re
import glob
import downloader
import GoDev
##F#T#G##
#!F!T!G!#
#@F@T@G@#
#$F$T$G$#
#%F%T%G%#
#^F^T^G^#
#&F&T&G&#
#&F&T&G&#
#*F*T*G*#
#(F)T(G)#
#-F-T-G-#
#_F_T_G_#
#+F+T+G+#

addon_id = 'plugin.program.fire'
MaintTitle="[COLOR orangered]FTG Maintenance[/COLOR]"
ART = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'resources/art'))
FANART = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
ICON = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
icon = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'resources/art/icon.png'))

#########################################################
### WEEKLY MAINT MESSAGE #################################
#########################################################
ACTION_PREVIOUS_MENU 			=  10	## ESC action
ACTION_NAV_BACK 				=  92	## Backspace action
ACTION_MOVE_LEFT				=   1	## Left arrow key
ACTION_MOVE_RIGHT 				=   2	## Right arrow key
ACTION_MOVE_UP 					=   3	## Up arrow key
ACTION_MOVE_DOWN 				=   4	## Down arrow key
ACTION_MOUSE_WHEEL_UP 			= 104	## Mouse wheel up
ACTION_MOUSE_WHEEL_DOWN			= 105	## Mouse wheel down
ACTION_MOVE_MOUSE 				= 107	## Down arrow key
ACTION_SELECT_ITEM				=   7	## Number Pad Enter
ACTION_BACKSPACE				= 110	## ?
		#%F%T%G%##%F%T%G%#
		
def WeeklyMaint(msg='', TxtColor='0xFFFFFFFF', Font='font30', BorderWidth=10):
	class MyWindow(xbmcgui.WindowDialog):
		scr={};
		def __init__(self,msg='',L=0,T=0,W=1280,H=720,TxtColor='0xFFFFFFFF',Font='font30',BorderWidth=10):
			image_path = os.path.join(ART, 'fanart.jpg')
			self.border = xbmcgui.ControlImage(L,T,W,H, image_path)
			self.addControl(self.border); 
			self.BG=xbmcgui.ControlImage(L+BorderWidth,T+BorderWidth,W-(BorderWidth*2),H-(BorderWidth*2), FANART, aspectRatio=0, colorDiffuse='0x5FFFFFFF')
			self.addControl(self.BG)
			#title
			title = MaintTitle
			times = int(float(Font[-2:]))
			temp = title.replace('[', '<').replace(']', '>')
			temp = re.sub('<[^<]+?>', '', temp)
			title_width = len(str(temp))*(times - 1)
			title = MaintTitle
			self.title=xbmcgui.ControlTextBox(L+(W-title_width)/2,T+BorderWidth,title_width,30,font='font20',textColor='0xFF1E90FF')#%F%T%G%#
			self.addControl(self.title)
			self.title.setText(title)
			#icon
			self.Icon=xbmcgui.ControlImage(L+(BorderWidth*2), T+BorderWidth+40, 150, 150, ICON, aspectRatio=0, colorDiffuse='0xFFFFFFFF')
			self.addControl(self.Icon)
			#welcome message
			msg = 'Weekly Maintenance was just done. If the icons are not showing up please reboot your Media Center'
			self.TxtMessage=xbmcgui.ControlTextBox(L+160+(BorderWidth*3),T+45,W-170-(BorderWidth*3),H-(BorderWidth*2)-50,font=Font,textColor=TxtColor)
			self.addControl(self.TxtMessage)
			self.TxtMessage.setText(msg)

		def doExit(self):
			self.CloseWindow()

		def onAction(self,action):
			try: F=self.getFocus()
			except: F=False
			if   action == ACTION_PREVIOUS_MENU: self.doExit()#%F%T%G%#
			elif action == ACTION_NAV_BACK: self.doExit()

		def CloseWindow(self): self.close()

	maxW=1280; maxH=720; W=int(700); H=int(250); L=int((maxW-W)/2); T=int((maxH-H)/2); 
	TempWindow=MyWindow(msg=msg,L=L,T=T,W=W,H=H,TxtColor=TxtColor,Font=Font,BorderWidth=BorderWidth); 
	TempWindow.doModal() 
	del TempWindow

#########################################################
### UPDATE MESSAGE#### ##################################
#########################################################
ACTION_PREVIOUS_MENU 			=  10	## ESC action
ACTION_NAV_BACK 				=  92	## Backspace action
ACTION_MOVE_LEFT				=   1	## Left arrow key
ACTION_MOVE_RIGHT 				=   2	## Right arrow key
ACTION_MOVE_UP 					=   3	## Up arrow key
ACTION_MOVE_DOWN 				=   4	## Down arrow key#%F%T%G%#
ACTION_MOUSE_WHEEL_UP 			= 104	## Mouse wheel up
ACTION_MOUSE_WHEEL_DOWN			= 105	## Mouse wheel down
ACTION_MOVE_MOUSE 				= 107	## Down arrow key
ACTION_SELECT_ITEM				=   7	## Number Pad Enter
ACTION_BACKSPACE				= 110	## ?

def updateWindow(TxtColor='0xFFFFFFFF', Font='font13', BorderWidth=10):
	class MyWindow(xbmcgui.WindowDialog):
		scr={};
		def __init__(self,msg='',L=0,T=0,W=1280,H=720,TxtColor='0xFFFFFFFF',Font='font30',BorderWidth=10):
			image_path = os.path.join(ART, 'fanart.jpg')
			self.border = xbmcgui.ControlImage(L,T,W,H, image_path)
			self.addControl(self.border); 
			self.BG=xbmcgui.ControlImage(L+BorderWidth,T+BorderWidth,W-(BorderWidth*2),H-(BorderWidth*2), FANART, aspectRatio=0, colorDiffuse='0x5FFFFFFF')
			self.addControl(self.BG)
			#title
			title = MaintTitle
			times = int(float(Font[-2:]))
			temp = title.replace('[', '<').replace(']', '>')
			temp = re.sub('<[^<]+?>', '', temp)
			title_width = len(str(temp))*(times - 1)#%F%T%G%#
			title = MaintTitle
			self.title=xbmcgui.ControlTextBox(L+(W-title_width)/2,T+BorderWidth,title_width,30,font='font20',textColor='0xFF1E90FF')
			self.addControl(self.title)
			self.title.setText(title)
			#welcome message
			msg =   'There is an Update avalible, choose from the options below. \n\nNew Install = Opens the wizard where you will choose -Fire TV Guru Builds- then the build you want. \n\nUpdate Install = Will do a Fresh Start. After its complete Force Close > Reopen the Media Center > choose New Install. \n\nIgnore = Ignores this prompt untill next start up.'
			self.update=xbmcgui.ControlTextBox(L+(BorderWidth*2),T+BorderWidth+30,W-150-(BorderWidth*3),H-(BorderWidth*2)-30,font=Font,textColor=TxtColor)
			self.addControl(self.update)
			self.update.setText(msg)
			#icon
			self.Icon=xbmcgui.ControlImage(L+W-(BorderWidth*1)-140, T+BorderWidth+0, 150, 150, icon, aspectRatio=0, colorDiffuse='0xFFFFFFFF')
			self.addControl(self.Icon)
			#buttons
			focus=os.path.join(ART, 'button-focus_lightblue.png'); nofocus=os.path.join(ART, 'button-focus_grey.png')
			w1      = int((W-(BorderWidth*5))/3); h1 = 35
			t       = int(T+H-h1-(BorderWidth*1.5))#%F%T%G%#
			fresh   = int(L+(BorderWidth*1.5))
			normal  = int(fresh+w1+BorderWidth)
			ignore  = int(normal+w1+BorderWidth)
			
			self.buttonFRESH=xbmcgui.ControlButton(fresh,t, w1,h1,"New Install",textColor="0xFFFFFFFF",focusedColor="0xFFFFFFFF",alignment=2,focusTexture=focus,noFocusTexture=nofocus)
			self.buttonNORMAL=xbmcgui.ControlButton(normal,t,w1,h1,"Update Install",textColor="0xFFFFFFFF",focusedColor="0xFFFFFFFF",alignment=2,focusTexture=focus,noFocusTexture=nofocus)
			self.buttonIGNORE=xbmcgui.ControlButton(ignore,t,w1,h1,"Ignore",textColor="0xFFFFFFFF",focusedColor="0xFFFFFFFF",alignment=2,focusTexture=focus,noFocusTexture=nofocus)
			self.addControl(self.buttonFRESH); self.addControl(self.buttonNORMAL); self.addControl(self.buttonIGNORE)
			self.buttonIGNORE.controlLeft(self.buttonNORMAL); self.buttonIGNORE.controlRight(self.buttonFRESH)
			self.buttonNORMAL.controlLeft(self.buttonFRESH); self.buttonNORMAL.controlRight(self.buttonIGNORE)
			self.buttonFRESH.controlLeft(self.buttonIGNORE); self.buttonFRESH.controlRight(self.buttonNORMAL)
			self.setFocus(self.buttonFRESH)#%F%T%G%#

		def doFreshInstall(self):
			self.CloseWindow()
			xbmc.executebuiltin("ActivateWindow(10025,plugin://plugin.program.fire/?mode=FireTVBuildMenu)")


		def doNormalInstall(self):
			self.CloseWindow()
			GoDev.freshstartUpdateWindow()

		def doIgnore(self):
			self.CloseWindow()

		def onAction(self,action):
			try: F=self.getFocus()
			except: F=False
			if   action == ACTION_PREVIOUS_MENU: self.doIgnore()
			elif action == ACTION_NAV_BACK: self.doIgnore()#%F%T%G%#
			elif action == ACTION_MOVE_LEFT and not F: self.setFocus(self.buttonIGNORE)
			elif action == ACTION_MOVE_RIGHT and not F: self.setFocus(self.buttonIGNORE)

		def onControl(self,control):
			if   control==self.buttonIGNORE: self.doIgnore()
			elif control==self.buttonNORMAL: self.doNormalInstall()
			elif control==self.buttonFRESH:  self.doFreshInstall()
			else:
				try:    self.setFocus(self.buttonIGNORE); 
				except: pass

		def CloseWindow(self): self.close()

	maxW=1280; maxH=720; W=int(700); H=int(350); L=int((maxW-W)/2); T=int((maxH-H)/2); 
	TempWindow=MyWindow(L=L,T=T,W=W,H=H,TxtColor=TxtColor,Font=Font,BorderWidth=BorderWidth); #%F%T%G%#
	TempWindow.doModal() 
	del TempWindow

#########################################################

#########################################################
### Maint Sizes window #########################################
#########################################################

#########################################################

#########################################################
### AUTO INSTALL ########################################
#########################################################

##########################################################%F%T%G%##%F%T%G%##%F%T%G%##%F%T%G%##%F%T%G%##%F%T%G%##%F%T%G%##%F%T%G%##%F%T%G%##%F%T%G%#

#########################################################
### NOTIFICATION WINDOW##################################
#########################################################

#########################################################