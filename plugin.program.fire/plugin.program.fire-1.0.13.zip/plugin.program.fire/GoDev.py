import threading,xbmc,xbmcplugin,xbmcgui,re,os,xbmcaddon,sys,xbmcvfs
import shutil
import glob
import zipfile
import urllib2,urllib
import urlparse
import xbmcgui
import time
import extract
import subprocess
import messages
global debuglog

ADDON          =  xbmcaddon.Addon(id='plugin.program.fire')
dialog         =  xbmcgui.Dialog()
DIALOG         =  xbmcgui.Dialog()
dialogprocess  =  xbmcgui.DialogProgress()
log_path       =  xbmc.translatePath('special://logpath/')
zip            =  ADDON.getSetting('zip')
USERDATA       =  xbmc.translatePath(os.path.join('special://home/userdata',''))
HOME           =  xbmc.translatePath('special://home/')
USB            =  xbmc.translatePath(os.path.join(zip))
homedir        =  xbmc.translatePath('special://home/')
packagesfolder =  xbmc.translatePath(os.path.join('special://home/addons','packages'))
thumbsfolder   =  xbmc.translatePath(os.path.join('special://home/userdata','Thumbnails'))
addondatafolder=  xbmc.translatePath(os.path.join('special://home/userdata','addon_data'))
addondir       =  xbmc.translatePath('special://home/addons/script.areswizard')
mainaddondir   =  xbmc.translatePath('special://home/addons')
temp1          =  xbmc.translatePath('special://home/userdata')
temp2          =  xbmc.translatePath('special://temp')
images_path    =  os.path.join(addondir, 'resources/images')
skin           =  xbmc.getSkinDir()
addon_id = 'plugin.program.fire'
ART = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'resources/art'))
FANART = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
icon = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'resources/art/icon.png'))
MaintTitle="[COLOR orangered]FTG UPDATER[/COLOR]"

try:
	from sqlite3 import dbapi2 as database
except:
	from pysqlite2 import dbapi2 as database
	
def get_size(start_path):
    total_size = 0
    for dirpath, dirnames, filenames in os.walk(start_path):
        for f in filenames:
            fp = os.path.join(dirpath, f)
            total_size += os.path.getsize(fp)
    return total_size

def convertSize(size):
   import math
   if (size == 0):
       return '[COLOR yellow][B]0 MB[/COLOR][/B]'
   size_name = ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
   i = int(math.floor(math.log(size,1024)))
   p = math.pow(1024,i)
   s = round(size/p,2)
   if size_name[i] == "B":
        return '[COLOR lime][B]%s %s' % (s,size_name[i]) + '[/COLOR][/B]'
   if size_name[i] == "KB":
        return '[COLOR yellow][B]%s %s' % (s,size_name[i]) + '[/COLOR][/B]'
   if size_name[i] == "GB":
        return '[COLOR lightskyblue][B]%s %s' % (s,size_name[i]) + '[/COLOR][/B]'
   if size_name[i] == "TB":
        return '[COLOR lightskyblue][B]%s %s' % (s,size_name[i]) + '[/COLOR][/B]'
   if s < 50:
        return '[COLOR yellow][B]%s %s' % (s,size_name[i]) + '[/COLOR][/B]'
   if s >= 50:
        if s < 100:
            return '[COLOR red][B]%s %s' % (s,size_name[i]) + '[/COLOR][/B]'
   if s >= 100:
        return '[COLOR lightskyblue][B]%s %s' % (s,size_name[i]) + '[/COLOR][/B]'

def convertSizeInstall(size):
   import math
   if (size == 0):
       return '[COLOR blue][B]0 MB[/COLOR][/B]'
   size_name = ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
   i = int(math.floor(math.log(size,1024)))
   p = math.pow(1024,i)
   s = round(size/p,2)
   if size_name[i] == "B":
        return '[COLOR lime][B]%s %s' % (s,size_name[i]) + '[/COLOR][/B]'
   if size_name[i] == "KB":
        return '[COLOR yellow][B]%s %s' % (s,size_name[i]) + '[/COLOR][/B]'
   if size_name[i] == "TB":
        return '[COLOR lightskyblue][B]%s %s' % (s,size_name[i]) + '[/COLOR][/B]'
   if s < 1000:
        return '[COLOR yellow][B]%s %s' % (s,size_name[i]) + '[/COLOR][/B]'
   if s >= 1000:
        if s < 1500:
            return '[COLOR red][B]%s %s' % (s,size_name[i]) + '[/COLOR][/B]'
   if s >= 1500:
        return '[COLOR lightskyblue][B]%s %s' % (s,size_name[i]) + '[/COLOR][/B]'
	
	
def maint():
	HOME       =  xbmc.translatePath('special://home/')
	CACHE      =  xbmc.translatePath(os.path.join('special://home/cache',''))
	PACKAGES   =  xbmc.translatePath(os.path.join('special://home/addons','packages'))
	THUMBS     =  xbmc.translatePath(os.path.join('special://home/userdata','Thumbnails'))

	if not os.path.exists(CACHE):
		CACHE     =  xbmc.translatePath(os.path.join('special://home/temp',''))
	if not os.path.exists(PACKAGES):
		os.makedirs(PACKAGES)

	try:
		CACHE_SIZE_BYTE    = get_size(CACHE)
		PACKAGES_SIZE_BYTE = get_size(PACKAGES)
		THUMB_SIZE_BYTE    = get_size(THUMBS)
	except: pass
	
	try:
		CACHE_SIZE    = convertSize(CACHE_SIZE_BYTE)
		PACKAGES_SIZE = convertSize(PACKAGES_SIZE_BYTE)
		THUMB_SIZE    = convertSize(THUMB_SIZE_BYTE)
	except: pass


	addFolder('',"[COLOR blue][B]-------------------------------------------------[/B][/COLOR]",'url',79,'','','')
	addFolder('',"[COLOR white][B]CACHE SIZE = [/B][/COLOR]" + str(CACHE_SIZE),'url',79,'','','')
	addFolder('',"[COLOR white][B]PACKAGES SIZE = [/B][/COLOR]" + str(PACKAGES_SIZE),'url',79,'','','')
	addFolder('',"[COLOR white][B]THUMBNAIL SIZE = [/B][/COLOR]" + str(THUMB_SIZE),'url',79,'','','')
	addFolder('',"[COLOR blue][B]-------------------------------------------------[/B][/COLOR]",'url',79,'','','')

EXCLUDES     = ['backupdir','plugin.program.fire','repository.fire' ,'script.module.addon.common','backup','FAVS', 'addon_data']
dp = xbmcgui.DialogProgress()
def freshstartUpdateWindow():
    choice = xbmcgui.Dialog().yesno("[COLOR=red]ABSOLUTELY CERTAIN?!!![/COLOR]", 'Are you absolutely certain you want to wipe this install?', '', 'All addons EXCLUDING The wizard and addon settings will be completely wiped!', yeslabel='[COLOR=red]Yes[/COLOR]',nolabel='[COLOR=green]No[/COLOR]')
    if choice == 0:
		messages.updateWindow()
    elif choice == 1:
        dp.create("[COLOR dodgerblue][B]Fire Wizard[/B][/COLOR]","Wiping Install",'', 'Please Wait')
        try:
            for root, dirs, files in os.walk(HOME,topdown=True):
                dirs[:] = [d for d in dirs if d not in EXCLUDES]
                for name in files:
                    try:
                        os.remove(os.path.join(root,name))
                        os.rmdir(os.path.join(root,name))
                    except: pass
                        
                for name in dirs:
                    try: os.rmdir(os.path.join(root,name)); os.rmdir(root)
                    except: pass
        except: pass
    REMOVE_EMPTY_FOLDERS()
    REMOVE_EMPTY_FOLDERS()
    REMOVE_EMPTY_FOLDERS()
    REMOVE_EMPTY_FOLDERS()
    REMOVE_EMPTY_FOLDERS()
    REMOVE_EMPTY_FOLDERS()
    REMOVE_EMPTY_FOLDERS()
    dp.close()
    killkodi()
################################################################################################################	
	
EXCLUDES     = ['backupdir','plugin.program.fire','repository.fire' ,'script.module.addon.common','backup','FAVS', 'addon_data']
dp = xbmcgui.DialogProgress()
def freshstart1():
    choice = xbmcgui.Dialog().yesno("[COLOR=red]ABSOLUTELY CERTAIN?!!![/COLOR]", 'Are you absolutely certain you want to wipe this install?', '', 'All addons EXCLUDING The wizard and addon settings will be completely wiped!', yeslabel='[COLOR=red]Yes[/COLOR]',nolabel='[COLOR=green]No[/COLOR]')
    if choice == 0:
        return
    elif choice == 1:
        dp.create("[COLOR dodgerblue][B]Fire Wizard[/B][/COLOR]","Wiping Install",'', 'Please Wait')
        try:
            for root, dirs, files in os.walk(HOME,topdown=True):
                dirs[:] = [d for d in dirs if d not in EXCLUDES]
                for name in files:
                    try:
                        os.remove(os.path.join(root,name))
                        os.rmdir(os.path.join(root,name))
                    except: pass
                        
                for name in dirs:
                    try: os.rmdir(os.path.join(root,name)); os.rmdir(root)
                    except: pass
        except: pass
    REMOVE_EMPTY_FOLDERS()
    REMOVE_EMPTY_FOLDERS()
    REMOVE_EMPTY_FOLDERS()
    REMOVE_EMPTY_FOLDERS()
    REMOVE_EMPTY_FOLDERS()
    REMOVE_EMPTY_FOLDERS()
    REMOVE_EMPTY_FOLDERS()
    dp.close()
    killkodi()


	
def TextBoxes(announce):
	class TextBox():
		WINDOW=10147
		CONTROL_LABEL=1
		CONTROL_TEXTBOX=5
		def __init__(self,*args,**kwargs):
			xbmc.executebuiltin("ActivateWindow(%d)" % (self.WINDOW, )) # activate the text viewer window
			self.win=xbmcgui.Window(self.WINDOW) # get window
			xbmc.sleep(500) # give window time to initialize
			self.setControls()
		def setControls(self):
			self.win.getControl(self.CONTROL_LABEL).setLabel('[COLOR red]FTG[COLOR snow] -[COLOR blue] View Log Facility[/COLOR]') # set heading
			try: f=open(announce); text=f.read()
			except: text=announce
			self.win.getControl(self.CONTROL_TEXTBOX).setText(str(text))
			return
	TextBox()
	while xbmc.getCondVisibility('Window.IsVisible(10147)'):
		time.sleep(.5)

def TextBoxesPlain(announce):
	class TextBox():
		WINDOW=10147
		CONTROL_LABEL=1
		CONTROL_TEXTBOX=5
		def __init__(self,*args,**kwargs):
			xbmc.executebuiltin("ActivateWindow(%d)" % (self.WINDOW, )) # activate the text viewer window
			self.win=xbmcgui.Window(self.WINDOW) # get window
			xbmc.sleep(500) # give window time to initialize
			self.setControls()
		def setControls(self):
			self.win.getControl(self.CONTROL_LABEL).setLabel('[COLOR red][B]FTG[/B][/COLOR]') # set heading
			try: f=open(announce); text=f.read()
			except: text=announce
			self.win.getControl(self.CONTROL_TEXTBOX).setText(str(text))
			return
	TextBox()
	while xbmc.getCondVisibility('Window.IsVisible(10147)'):
		time.sleep(.5)
		
def _get_keyboard( default="", heading="", hidden=False ):
    """ shows a keyboard and returns a value """
    keyboard = xbmc.Keyboard( default, heading, hidden )
    keyboard.doModal()
    if ( keyboard.isConfirmed() ):
        return unicode( keyboard.getText(), "utf-8" )
    return default
	
def REMOVE_EMPTY_FOLDERS():
#initialize the counters
    print"########### Start Removing Empty Folders #########"
    empty_count = 0
    used_count = 0
    for curdir, subdirs, files in os.walk(HOME):
        if len(subdirs) == 0 and len(files) == 0: #check for empty directories. len(files) == 0 may be overkill
            empty_count += 1 #increment empty_count
            os.rmdir(curdir) #delete the directory
            print "successfully removed: "+curdir
        elif len(subdirs) > 0 and len(files) > 0: #check for used directories
            used_count += 1 #increment used_count
	
def killkodi():
	myplatform = platform()
	os._exit(1)
	log("Force close failed!  Trying alternate methods.")
	if myplatform == 'osx': # OSX
		log("############ try osx force close #################")
		try: os.system('killall -9 XBMC')
		except: pass
		try: os.system('killall -9 Kodi')
		except: pass
		DIALOG.ok("[COLOR=red][B]WARNING !!![/COLOR][/B]", "If you\'re seeing this message it means the force close", "was unsuccessful. Please force close XBMC/Kodi [COLOR=lime]DO NOT[/COLOR] exit cleanly via the menu.",'')
	elif myplatform == 'linux': #Linux
		log("############ try linux force close #################")
		try: os.system('killall XBMC')
		except: pass
		try: os.system('killall Kodi')
		except: pass
		try: os.system('killall -9 xbmc.bin')
		except: pass
		try: os.system('killall -9 kodi.bin')
		except: pass
		DIALOG.ok("[COLOR=red][B]WARNING !!![/COLOR][/B]", "If you\'re seeing this message it means the force close", "was unsuccessful. Please force close XBMC/Kodi [COLOR=lime]DO NOT[/COLOR] exit cleanly via the menu.",'')
	elif myplatform == 'android': # Android 
		log("############ try android force close #################")
		try: os.system('adb shell am force-stop org.xbmc.kodi')
		except: pass
		try: os.system('adb shell am force-stop org.kodi')
		except: pass
		try: os.system('adb shell am force-stop org.xbmc.xbmc')
		except: pass
		try: os.system('adb shell am force-stop org.xbmc')
		except: pass		
		try: os.system('adb shell kill org.xbmc.kodi')
		except: pass
		try: os.system('adb shell kill org.kodi')
		except: pass
		try: os.system('adb shell kill org.xbmc.xbmc')
		except: pass
		try: os.system('adb shell kill org.xbmc')
		except: pass
		try: os.system('Process.killProcess(android.os.Process.org.xbmc,kodi());')
		except: pass
		try: os.system('Process.killProcess(android.os.Process.org.kodi());')
		except: pass
		try: os.system('Process.killProcess(android.os.Process.org.xbmc.xbmc());')
		except: pass
		try: os.system('Process.killProcess(android.os.Process.org.xbmc());')
		except: pass
		try: os.system('Process.killProcess(android.os.Process.org.fire.guru());')
		except: pass
		try: os.system('Process.killProcess(android.os.Process.org.fire.guruv());')
		except: pass
		try: os.system('Process.killProcess(android.os.Process.com.semperpax.spmc16());')
		except: pass
		try: os.system('Process.killProcess(android.os.Process.org.fire());')
		except: pass
		try: os.system('Process.killProcess(android.os.Process.org.fire,guru());')
		except: pass
		DIALOG.ok( "[COLOR=red][B]WARNING !!![/COLOR][/B]","Press the HOME button on your remote and [COLOR=red][B]FORCE STOP[/COLOR][/B] KODI via the Manage Installed Applications menu in settings on your Amazon home page then re-launch KODI")
	elif myplatform == 'windows': # Windows
		log("############ try windows force close #################")
		try:
			os.system('@ECHO off')
			os.system('tskill XBMC.exe')
		except: pass
		try:
			os.system('@ECHO off')
			os.system('tskill Kodi.exe')
		except: pass
		try:
			os.system('@ECHO off')
			os.system('TASKKILL /im Kodi.exe /f')
		except: pass
		try:
			os.system('@ECHO off')
			os.system('TASKKILL /im XBMC.exe /f')
		except: pass
		DIALOG.ok("[COLOR=red][B]WARNING !!![/COLOR][/B]", "If you\'re seeing this message it means the force close", "was unsuccessful. Please force close XBMC/Kodi [COLOR=lime]DO NOT[/COLOR] exit cleanly via the menu.","Use task manager and NOT ALT F4")
	else: #ATV
		log("############ try atv force close #################")
		try: os.system('killall AppleTV')
		except: pass
		log("############ try raspbmc force close #################") #OSMC / Raspbmc
		try: os.system('sudo initctl stop kodi')
		except: pass
		try: os.system('sudo initctl stop xbmc')
		except: pass
		DIALOG.ok("[COLOR=red][B]WARNING !!![/COLOR][/B]", "If you\'re seeing this message it means the force close", "was unsuccessful. Please force close XBMC/Kodi [COLOR=lime]DO NOT[/COLOR] exit via the menu.","iOS detected. Press and hold both the Sleep/Wake and Home button for at least 10 seconds, until you see the Apple logo.")



		
def OPEN_URL(url):
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link
		
def platform():
	if xbmc.getCondVisibility('system.platform.android'):
		return 'android'
	elif xbmc.getCondVisibility('system.platform.linux'):
		return 'linux'
	elif xbmc.getCondVisibility('system.platform.windows'):
		return 'windows'
	elif xbmc.getCondVisibility('system.platform.osx'):
		return 'osx'
	elif xbmc.getCondVisibility('system.platform.atv2'):
		return 'atv2'
	elif xbmc.getCondVisibility('system.platform.ios'):
		return 'ios'
		
try:
	debuglog = xbmcplugin.getSetting(int(sys.argv[1]), 'debuglog')
except:
	debuglog = "0"	
		
def Add_Directory_Item(handle, url, listitem, isFolder):
	xbmcplugin.addDirectoryItem(handle, url, listitem, isFolder)  	

def Delete_Packages():
	print 'DELETING PACKAGES'
	packages_cache_path = xbmc.translatePath(os.path.join('special://home/addons/packages', ''))
	for root, dirs, files in os.walk(packages_cache_path):
		file_count = 0
		file_count += len(files)
	# Count files and give option to delete
		if file_count > 0:
			for f in files:
				os.unlink(os.path.join(root, f))
			for d in dirs:
				shutil.rmtree(os.path.join(root, d))
def Delete_Logs():  
	for infile in glob.glob(os.path.join(log_path, 'xbmc_crashlog*.*')):
		 File=infile
		 print infile
		 os.remove(infile)
		 dialog = xbmcgui.Dialog()
  
def Wipe_Cache():
	xbmc_cache_path = os.path.join(xbmc.translatePath('special://home'), 'cache')
	if os.path.exists(xbmc_cache_path)==True:
		for root, dirs, files in os.walk(xbmc_cache_path):
			file_count = 0
			file_count += len(files)
			if file_count > 0:
				for f in files:
					try:
						os.unlink(os.path.join(root, f))
					except:
						pass
				for d in dirs:
					try:
						shutil.rmtree(os.path.join(root, d))
					except:
						pass
	if xbmc.getCondVisibility('system.platform.ATV2'):
		atv2_cache_a = os.path.join('/private/var/mobile/Library/Caches/AppleTV/Video/', 'Other')
		for root, dirs, files in os.walk(atv2_cache_a):
			file_count = 0
			file_count += len(files)
			if file_count > 0:
				for f in files:
					os.unlink(os.path.join(root, f))
				for d in dirs:
					shutil.rmtree(os.path.join(root, d))
		atv2_cache_b = os.path.join('/private/var/mobile/Library/Caches/AppleTV/Video/', 'LocalAndRental')		
		for root, dirs, files in os.walk(atv2_cache_b):
			file_count = 0
			file_count += len(files)
			if file_count > 0:
				for f in files:
					os.unlink(os.path.join(root, f))
				for d in dirs:
					shutil.rmtree(os.path.join(root, d))
	# Set path to script.module.simple.downloader cache files
	downloader_cache_path = os.path.join(xbmc.translatePath('special://profile/addon_data/script.module.simple.downloader'), '')
	if os.path.exists(downloader_cache_path)==True:	
		for root, dirs, files in os.walk(downloader_cache_path):
			file_count = 0
			file_count += len(files)
			if file_count > 0:
				for f in files:
					os.unlink(os.path.join(root, f))
				for d in dirs:
					shutil.rmtree(os.path.join(root, d))
	# Set path to script.image.music.slideshow cache files
	imageslideshow_cache_path = os.path.join(xbmc.translatePath('special://profile/addon_data/script.image.music.slideshow/cache'), '')
	if os.path.exists(imageslideshow_cache_path)==True:	
		for root, dirs, files in os.walk(imageslideshow_cache_path):
			file_count = 0
			file_count += len(files)
			if file_count > 0:
				for f in files:
					os.unlink(os.path.join(root, f))
				for d in dirs:
					shutil.rmtree(os.path.join(root, d))
	# Set path to BBC iPlayer cache files
	iplayer_cache_path= os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.iplayer/iplayer_http_cache'), '')
	if os.path.exists(iplayer_cache_path)==True:	
		for root, dirs, files in os.walk(iplayer_cache_path):
			file_count = 0
			file_count += len(files)
			if file_count > 0:
				for f in files:
					os.unlink(os.path.join(root, f))
				for d in dirs:
					shutil.rmtree(os.path.join(root, d))
	itv_cache_path = os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.itv/Images'), '')
	if os.path.exists(itv_cache_path)==True:	
		for root, dirs, files in os.walk(itv_cache_path):
			file_count = 0
			file_count += len(files)
			if file_count > 0:
				for f in files:
					os.unlink(os.path.join(root, f))
				for d in dirs:
					shutil.rmtree(os.path.join(root, d))
	navix_cache_path= os.path.join(xbmc.translatePath('special://profile/addon_data/script.navi-x/cache'), '')
	if os.path.exists(navix_cache_path)==True:	
		for root, dirs, files in os.walk(navix_cache_path):
			file_count = 0
			file_count += len(files)
			if file_count > 0:
				for f in files:
					os.unlink(os.path.join(root, f))
				for d in dirs:
					shutil.rmtree(os.path.join(root, d))
	phoenix_cache_path= os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.phstreams/Cache'), '')
	if os.path.exists(phoenix_cache_path)==True:	
		for root, dirs, files in os.walk(phoenix_cache_path):
			file_count = 0
			file_count += len(files)
			if file_count > 0:
				for f in files:
					os.unlink(os.path.join(root, f))
				for d in dirs:
					shutil.rmtree(os.path.join(root, d))
	ramfm_cache_path= os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.audio.ramfm/cache'), '')
	if os.path.exists(ramfm_cache_path)==True:	
		for root, dirs, files in os.walk(ramfm_cache_path):
			file_count = 0
			file_count += len(files)
			if file_count > 0:
				for f in files:
					os.unlink(os.path.join(root, f))
				for d in dirs:
					shutil.rmtree(os.path.join(root, d))
	wtf_cache_path = os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.whatthefurk/cache'), '')
	if os.path.exists(wtf_cache_path)==True:	
		for root, dirs, files in os.walk(wtf_cache_path):
			file_count = 0
			file_count += len(files)
			if file_count > 0:
				for f in files:
					os.unlink(os.path.join(root, f))
				for d in dirs:
					shutil.rmtree(os.path.join(root, d))
	try:
		genesisCache = os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.genesis'), 'cache.db')
		dbcon = database.connect(genesisCache)
		dbcur = dbcon.cursor()
		dbcur.execute("DROP TABLE IF EXISTS rel_list")
		dbcur.execute("VACUUM")
		dbcon.commit()
		dbcur.execute("DROP TABLE IF EXISTS rel_lib")
		dbcur.execute("VACUUM")
		dbcon.commit()
	except:
		pass
def Destroy_Path(path):
	dialogprocess.create("Fire TV","Cleaning...",'', 'Please Wait')
	shutil.rmtree(path, ignore_errors=True)
def Remove_Textures():
	textures   =  xbmc.translatePath('special://home/userdata/Database/Textures13.db')
	try:
		dbcon = database.connect(textures)
		dbcur = dbcon.cursor()
		dbcur.execute("DROP TABLE IF EXISTS path")
		dbcur.execute("VACUUM")
		dbcon.commit()
		dbcur.execute("DROP TABLE IF EXISTS sizes")
		dbcur.execute("VACUUM")
		dbcon.commit()
		dbcur.execute("DROP TABLE IF EXISTS texture")
		dbcur.execute("VACUUM")
		dbcon.commit()
		dbcur.execute("""CREATE TABLE path (id integer, url text, type text, texture text, primary key(id))""")
		dbcon.commit()
		dbcur.execute("""CREATE TABLE sizes (idtexture integer,size integer, width integer, height integer, usecount integer, lastusetime text)""")
		dbcon.commit()
		dbcur.execute("""CREATE TABLE texture (id integer, url text, cachedurl text, imagehash text, lasthashcheck text, PRIMARY KEY(id))""")
		dbcon.commit()
	except:
		pass




def freshstart():

	choice = xbmcgui.Dialog().yesno('[COLOR dodgerblue][B]Fire Wizard[/COLOR][/B]  [COLOR=red][B]WARNING !!![/COLOR][/B]', '		  This will erase ALL data and reset Kodi to defaults!!!','   Kodi will try to force close after the process is complete.', '							 [COLOR=red][B]Do you want to continue?[/COLOR][/B]', nolabel='Nope',yeslabel='YES')
	if choice == 0:
		return
	elif choice == 1:
		pass

		dp = xbmcgui.DialogProgress()
	dp.create("Fire Wizard","Please Wait")
	dp.update(1)

	
	path  = xbmc.translatePath('special://Database')
	files = glob.glob(os.path.join(path, 'Textures*.db'))
	for f in files:		
		try:
			os.remove(f)
		except:
			Shrink(f)



	for root, dirs, files in os.walk(homedir):
			for f in files:
							try:
									if f == "kodi.log" or f == "build.zip":
										pass
									else:
										path = os.path.join(root, f)
										if 'repository.firetvguru' not in path and 'plugin.program.fire' not in path and 'script.module.elementtree' not in path:
											dp.update(1, '', '', 'Deleting: ' + f)
											os.unlink(path)
											print 'from HOMEDIR deleted: ' + root + f
							except:
									pass
			for d in dirs:
							try:
									if d == "Database" or d == "addon_data" or d == "userdata" or d == "packages" or d == "addons" or d == "Thumbnails" or d == "temp" or d == "repository.firetvguru" or d == "plugin.program.fire" or d == "script.module.elementtree":
										pass
									else:
										path = os.path.join(root, d)
										if 'repository.firetvguru' not in path and 'plugin.program.fire' not in path and 'script.module.elementtree' not in path:
											dp.update(1, '', '', 'Deleting: ' + d)
											shutil.rmtree(os.path.join(root, d))
											print 'from HOMEDIR removed folder: ' + os.path.join(root, d)
							except:
									pass
											
			
	dp.update(30)



			
			
	for root, dirs, files in os.walk(addondatafolder):
			for f in files:
							try:
									dp.update(30, '', '', 'Deleting: ' + f)
									path = os.path.join(root, f)
									if 'repository.firetvguru' not in path:
										os.unlink(os.path.join(root, f))
										print 'from ADDONDATA deleted: ' + root + f
							except:
									pass
			for d in dirs:
							try:
									dp.update(30, '', '', 'Deleting: ' + d)
									path = os.path.join(root, d)
									if 'repository.firetvguru' not in path:
										shutil.rmtree(os.path.join(root, d))
										print 'from ADDONDATA removed folder: ' + os.path.join(root, d)
							except:
												pass		
				
			
	dp.update(50)


	for root, dirs, files in os.walk(temp1):
			for f in files:
							try:
									dp.update(50, '', '', 'Deleting: ' + f)
									path = os.path.join(root, f)
									if 'repository.firetvguru' not in path:
										os.unlink(os.path.join(root, f))
										print 'from TEMP1 deleted: ' + root + f
							except:
									pass
			for d in dirs:
							try:
									if d == "Database" or d == "addon_data" or d == "Thumbnails":
										pass
									else:
										dp.update(50, '', '', 'Deleting: ' + d)
										path = os.path.join(root, d)
										if 'repository.firetvguru' not in path :
											shutil.rmtree(os.path.join(root, d))
											print 'from TEMP1 removed folder: ' + os.path.join(root, d)
							except:
									pass	


	dp.update(65)



	for root, dirs, files in os.walk(temp2):
			for f in files:
							try:
									if f == "kodi.log" or f == "build.zip":
										pass
									else:
										dp.update(50, '', '', 'Deleting: ' + f)
										os.unlink(os.path.join(root, f))
										print 'from TEMP1 deleted: ' + root + f
							except:
									pass
			for d in dirs:
							try:
									dp.update(50, '', '', 'Deleting: ' + d)
									shutil.rmtree(os.path.join(root, d))
									print 'from TEMP2 removed folder: ' + os.path.join(root, d)
							except:
									pass	


	dp.update(70)




	for root, dirs, files in os.walk(packagesfolder):
		for f in files:
						try:
								if f == "kodi.log" or f == "build.zip":
									pass
								else:
									dp.update(50, '', '', 'Deleting: ' + f)
									os.unlink(os.path.join(root, f))
									print 'from PACKAGES deleted: ' + root + f
						except:
								pass
		for d in dirs:
						try:
								dp.update(50, '', '', 'Deleting: ' + d)
								shutil.rmtree(os.path.join(root, d))
								print 'from PACKAGES removed folder: ' + os.path.join(root, d)
						except:
								pass	


	dp.update(75)


	for root, dirs, files in os.walk(thumbsfolder):
			for f in files:
							try:
									dp.update(75, '', '', 'Deleting: ' + f)
									os.unlink(os.path.join(root, f))
									print 'from THUMBS deleted: ' + root + f
							except:
									pass
			for d in dirs:
							try:
									dp.update(75, '', '', 'Deleting: ' + d)
									shutil.rmtree(os.path.join(root, d))
									print 'from THUMBS removed folder: ' + os.path.join(root, d)
							except:
									pass	

			
			
	dp.update(85)


	for root, dirs, files in os.walk(mainaddondir):
			for f in files:
							try:
									if f == "kodi.log" or f == "build.zip":
										pass
									else:
										path = os.path.join(root, f)
										if 'repository.firetvguru' not in path and 'plugin.program.fire' not in path and 'script.module.elementtree' not in path:
											dp.update(85, '', '', 'Deleting: ' + f)
											os.unlink(path)
											print 'from MAINADDONDIR deleted: ' + root + f
							except:
									pass
			for d in dirs:
							try:
									if d == "packages" or d == "repository.firetvguru" or d == "plugin.program.fire" or d == "script.module.elementtree":
										pass
									else:
										if 'repository.firetvguru' not in path and 'plugin.program.fire' not in path and 'script.module.elementtree' not in path:
											dp.update(85, '', '', 'Deleting: ' + d)
											shutil.rmtree(os.path.join(root, d))
											print 'from MAINADDONDIR removed folder: ' + os.path.join(root, d)
							except:
									pass	

	dp.close
	killkodi()	