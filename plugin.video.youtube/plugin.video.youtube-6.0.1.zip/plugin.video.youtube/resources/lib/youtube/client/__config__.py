# -*- coding: utf-8 -*-
from base64 import b64decode
from hashlib import md5
from resources.lib.kodion import Context as __Context

DEFAULT_SWITCH = 1

__context = __Context()
__settings = __context.get_settings()

_own_key = __settings.get_string('youtube.api.key', '').strip()
_own_id = __settings.get_string('youtube.api.id', '').replace('.apps.googleusercontent.com', '').strip()
_own_secret = __settings.get_string('youtube.api.secret', '').strip()

__settings.set_string('youtube.api.key', _own_key)
__settings.set_string('youtube.api.id', _own_id)
__settings.set_string('youtube.api.secret', _own_secret)


def _has_own_keys():
    return False if not _own_key or \
                    not _own_id or \
                    not _own_secret or \
                    not __settings.get_bool('youtube.api.enable', False) else True


has_own_keys = _has_own_keys()


def __get_key_switch():
    switch = __settings.get_string('youtube.api.key.switch', str(DEFAULT_SWITCH))
    use_switch = __settings.get_string('youtube.api.key.switch.use', '')
    if not use_switch and switch:
        switch = 'own' if has_own_keys else str(DEFAULT_SWITCH)
        __settings.set_string('youtube.api.key.switch', switch)
        __settings.set_string('youtube.api.key.switch.use', switch)
        return switch
    elif use_switch != switch:
        __settings.set_string('youtube.api.key.switch.use', switch)
        return switch
    else:
        return use_switch


key_sets = {
    'youtube-tv': {
        'id': 'ODYxNTU2NzA4NDU0LWQ2ZGxtM2xoMDVpZGQ4bnBlazE4azZiZThiYTNvYzY4',
        'key': 'QUl6YVN5QWQtWUVPcVp6OW5YVnpHdG4zS1d6WUxiTGFhamhxSURB',
        'secret': 'U2JvVmhvRzlzMHJOYWZpeENTR0dLWEFU'
    },
    'own': {
        'key': _own_key,
        'id': _own_id,
        'secret': _own_secret
    },
    'provided': {
        'switch': __get_key_switch(),
        '0': {  # youtube-plugin-for-kodi-2
            'id': 'ODYxNTU2NzA4NDU0LWQ2ZGxtM2xoMDVpZGQ4bnBlazE4azZiZThiYTNvYzY4',
            'key': 'QUl6YVN5Q1pNSWlMS0o1OVhtejRUYzJ3NkM2MWRrcThKWFUtXzlr',
            'secret': 'U2JvVmhvRzlzMHJOYWZpeENTR0dLWEFU'
        },
        '1': {  # youtube-plugin-for-kodi
            'id': 'ODYxNTU2NzA4NDU0LWQ2ZGxtM2xoMDVpZGQ4bnBlazE4azZiZThiYTNvYzY4',
            'key': 'QUl6YVN5QndOUzZuRk1tczJoYlZnOXRjUDQySzEzZ2RsQ2JvV1VF',
            'secret': 'U2JvVmhvRzlzMHJOYWZpeENTR0dLWEFU',
        },
        '2': {  # youtube-plugin-for-kodi-3
            'id': 'ODYxNTU2NzA4NDU0LWQ2ZGxtM2xoMDVpZGQ4bnBlazE4azZiZThiYTNvYzY4',
            'key': 'QUl6YVN5RE5oZG1CV2xVRldoeVg0MzBoZFpqWDYta0ZEM2FzRHNF',
            'secret': 'U2JvVmhvRzlzMHJOYWZpeENTR0dLWEFU'
        },
        '3': {  # youtube-plugin-for-kodi-4
            'id': 'ODYxNTU2NzA4NDU0LWQ2ZGxtM2xoMDVpZGQ4bnBlazE4azZiZThiYTNvYzY4',
            'key': 'QUl6YVN5QTJiU1M0QWVuMjR2ZVlGS0NGRFIzdFlJT1ppSGppRWhF',
            'secret': 'U2JvVmhvRzlzMHJOYWZpeENTR0dLWEFU'
        },
        '4': {  # youtube-plugin-for-kodi-5
            'id': 'ODYxNTU2NzA4NDU0LWQ2ZGxtM2xoMDVpZGQ4bnBlazE4azZiZThiYTNvYzY4',
            'key': 'QUl6YVN5QUdrM2hGNVMxZWszeElhM1cxX2FtREV2MGU2SGpsQzdR',
            'secret': 'U2JvVmhvRzlzMHJOYWZpeENTR0dLWEFU'
        },
        '5': {  # youtube-plugin-for-kodi-6
            'id': 'ODYxNTU2NzA4NDU0LWQ2ZGxtM2xoMDVpZGQ4bnBlazE4azZiZThiYTNvYzY4',
            'key': 'QUl6YVN5RGxsN0IzM1JfTFJwbWdHSjZTZU1mVC1RNURfQkxXcUc4',
            'secret': 'U2JvVmhvRzlzMHJOYWZpeENTR0dLWEFU'
        }
    }
}


def get_current_switch():
    return 'own' if has_own_keys else key_sets['provided']['switch']


def get_last_switch():
    return __settings.get_string('youtube.api.last.switch', '')


def set_last_switch(value):
    __settings.set_string('youtube.api.last.switch', value)


def get_key_set_hash(value):
    m = md5()
    if value == 'own':
        m.update('%s%s%s' % (key_sets[value]['key'], key_sets[value]['id'], key_sets[value]['secret']))
    else:
        m.update('%s%s%s' % \
                 (key_sets['provided'][value]['key'], key_sets['provided'][value]['id'],
                  key_sets['provided'][value]['secret']))
    return m.hexdigest()


def set_last_hash(value):
    __settings.set_string('youtube.api.last.hash', get_key_set_hash(value))


def get_last_hash():
    return __settings.get_string('youtube.api.last.hash', '')


def _resolve_old_login():
    __context.log_debug('API key set changed: Signing out')
    __context.execute('RunPlugin(%s)' % __context.create_uri(['sign', 'out']))


# make sure we have a valid switch, if not use default
if not has_own_keys:
    if not key_sets['provided'].get(key_sets['provided']['switch'], None):
        __settings.set_string('youtube.api.key.switch', str(DEFAULT_SWITCH))
        key_sets['provided']['switch'] = __get_key_switch()


def check_for_key_changes():
    last_switch = get_last_switch()
    current_switch = get_current_switch()
    __context.log_debug('Using API key set: %s' % current_switch)
    last_set_hash = get_last_hash()
    current_set_hash = get_key_set_hash(current_switch)
    if (last_switch != current_switch) or (last_set_hash != current_set_hash):
        __context.log_warning('Switching API key set from %s to %s' % (last_switch, current_switch))
        set_last_switch(current_switch)
        set_last_hash(current_switch)
        _resolve_old_login()
        return True
    return False


api = {
    'key':
        key_sets['own']['key']
        if has_own_keys
        else
        b64decode(key_sets['provided'][key_sets['provided']['switch']]['key']),
    'id':
        '%s.apps.googleusercontent.com' %
        (key_sets['own']['id']
         if has_own_keys
         else
         b64decode(key_sets['provided'][key_sets['provided']['switch']]['id'])),
    'secret':
        key_sets['own']['secret']
        if has_own_keys
        else
        b64decode(key_sets['provided'][key_sets['provided']['switch']]['secret'])
}

youtube_tv = {
    'key': b64decode(key_sets['youtube-tv']['key']),
    'id': '%s.apps.googleusercontent.com' % b64decode(key_sets['youtube-tv']['id']),
    'secret': b64decode(key_sets['youtube-tv']['secret'])
}

keys_changed = check_for_key_changes()
